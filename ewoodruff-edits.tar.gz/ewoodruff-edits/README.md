# Project space for CIS 422 at UofO

This is our project space for CIS 422, it'll house the code for our two projects. 

Current Project:

Address Book

# Team Members

Adam Carlton [Manager/Programmer],
Zachary Trudo,
Elizabeth Woodruff,
Wilson Chen,
Alex Dibb,
Xuesong Luo
