
import basicCLI
import os
import sys
import fileops
import address
import addressbook
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

class C_to_G(basicCLI.CLI):
    #list to display on main menu

    def __init__(self, fname=''):
        try:
            self.addb = addressbook.AddressBook
           # self.fname = self.addb.fileName
            #self.aBook = []
            self.set_file(fname)
            #self.load()
        except:
            print("trouble in creating C_to_G")

    def get_Book_List(self, book_list):
        #get address books in local directory for main menu to display. NEED TO FIX: how to get it to recognize addb file
        for subdir, dirs, files in os.walk('./'):
            for item in files:

                try:
                    fileops.FileOps.open_address_book(item)
                    book_list.append(item)
                    #self.set_file(item)
                    print("IS: addb " + item.fileName)
                except basicCLI.FileNotFoundException:
                    pass
                except IOError:
                    print("IOerror")
                except:
                    print("some other error in get_Book_List")
                    #print("not addb:{}\n".format(item))
    def open_GUI_Addb(self, addb, name):
        try:
            #self.addb.fileName = name
            self.set_file(name)
            self.addb = fileops.FileOps.open_address_book(name)
            #self.addb = addb
            self.load()
        except:
            pass

        return self.addb

    def save_GUI_Addb(self,addb):
        self.fname = addb.fileName
        self.addb = addb
        print(self.addb.fileName)
        fileops.FileOps.save_address_book(self.addb)
        print("done saving")
        self.addb = fileops.FileOps.open_address_book(addb.fileName)
        self.load()
        print("done loading")
        #self._increment_state()
        #print("done incrementing")
        return
    def create_GUI_Addb(self,addb1):
        try:
            fileops.FileOps.save_address_book_as(addb1, addb1.fileName)
            self.addb = addb1
            self.fname = addb1.fileName
        except IOError:
            print("error in create")
        except:
            pass
        return

    def delete_GUI_contact(self,contact):
        #self.load()
        self.delete(contact)
        #self.addb.delete_address(contact)
       # self.save_GUI_Addb(self.addb)
        return
    def update_GUI_contact(self,addb, contact):
        addy = contact
        previous_addy_book = self.aBook[self.state]
        self._increment_state()
        self.aBook[self.state] = previous_addy_book
        return
    """
     if contact in self.addb.addresses:
            self.save_GUI_Addb(self, addb)
            self._increment_state()
        self.load()
    """



    def create_GUI_contact(self,addb, contact):
        """addb.add_address(contact)
        self.load()
        self._increment_state()
        """
        try:
            #self.fname = addb.fileName
            #self.create(contact)
            addy = contact
            previous_addy_book = self.aBook[self.state]
            self._increment_state()
            self.aBook[self.state] = previous_addy_book
            self.aBook[self.state].add_address(addy)

        except IOError:
            pass
        except:
            self.aBook = [None for _ in range(0, 19)]
            self.aBook[self.state] = fileops.FileOps.open_address_book(self.fname)
        return

    def search_GUI_contact(self,addb, contact):
        pass
    def GUI_undo(self, addb):
        addb = self.undo()
        self.load()
        return
    def GUI_redo(self, addb):
        addb = self.redo()
        self.load()
        return
if __name__ == '__main__':
    li = []

    example = C_to_G()
    exampleA = addressbook.AddressBook("TESTer1")
    exampleA.fileName = "TESTer1"
   # example.open_GUI_Addb(exampleA)
    ex_contact = address.Address("emily", "rose", 1, "b", "c", "d", "e")
    other_contact = address.Address("harry", "potter", 4, "d", "k", "d", "l")
    example.get_Book_List(li)
    for i in li:
        print(i)

    print("testing open:{}".format(example.fname))
    example.addb.fileName = example.fname
    example.open_GUI_Addb(example.addb, example.addb.fileName)

    print("testing create new contact:{}".format(ex_contact.last_name))
    example.create_GUI_contact(example.addb, ex_contact)
    print("after creating")
    for c in example.addb.addresses:
        print(c)
    print("testing delete:{}".format(other_contact.last_name))
    #example.delete_GUI_contact(ex_contact)
    try:
        example.create_GUI_contact(example.addb, other_contact)
        example.delete_GUI_contact(other_contact)
        print("after delete")
        for c in example.addb.addresses:
            print(c)
    except:
        print('delete not working')
    print("testing undo")
    try:
        example.undo()
        for c in example.addb.addresses:
            print(c)
    except:
        print("undo not working")

    print("testing redo")
    try:
        example.redo()
        for c in example.addb.addresses:
            print(c)
    except:
        print("redo not working")
