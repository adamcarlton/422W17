from Tkinter import *
import edit_UI
import Contact_UI

def Info(TheName, cg, contact):
    addb = cg.addb
    info = Tk()
    info.title("Address Book Contact")
    info.geometry('250x200')
    name = TheName

    frame1 = Frame(info)
    frame1.pack()
    label1 = Label(frame1, text = TheName, font = 'Helvetica -18 bold')
        
    label1.grid(row = 0, column = 0)


    frame2 = Frame(info)
    frame2.pack(fill = BOTH, expand = YES)
    PhoneLabel = Label(frame2, text = "Phone: ", font = 'Helvetica -14')
    AddressLabel = Label(frame2, text = "Address: ", font = 'Helvetica -14')
    CityLabel = Label(frame2, text = "City: ", font = 'Helvetica -14')
    StateLabel = Label(frame2, text = "State: ", font = 'Helvetica -14')
    ZipLabel = Label(frame2, text = "Zip: ", font = 'Helvetica -14')

    PhoneLabel.grid(row = 0, column = 0)
    AddressLabel.grid(row = 1, column = 0)
    CityLabel.grid(row = 2, column = 0)
    StateLabel.grid(row = 3, column = 0)
    ZipLabel.grid(row = 4, column = 0)

    PhoneLabelInfo = Label(frame2, text = contact["first_name"] + " " + contact["last_name"], font = 'Helvetica -14')
    AddressLabelInfo = Label(frame2, text=(str(contact["house_number"]) + " "+  contact["street"]), font='Helvetica -14')
    CityLabelInfo = Label(frame2, text=contact["city"], font='Helvetica -14')
    StateLabelInfo = Label(frame2, text=contact["state"], font='Helvetica -14')
    ZipLabelInfo = Label(frame2, text=contact["zipcode"], font='Helvetica -14')

    PhoneLabelInfo.grid(row=0, column=1)
    AddressLabelInfo.grid(row=1, column=1)
    CityLabelInfo.grid(row=2, column=1)
    StateLabelInfo.grid(row=3, column=1)
    ZipLabelInfo.grid(row=4, column=1)

    frame3 = Frame(info)
    frame3.pack(side = BOTTOM, fill = X)

    def EditContacts():
        edit_UI.Edit(contact, cg)
        info.destroy()
    def delete():
        action = "deleting contact"
        Contact_UI.ConfirmAction(cg.addb, action)
        if action is "y":
            if contact in cg.addb:
                cg.delete_GUI_contact(contact)
                info.destroy()
        else:
            info.destroy()
    button1 = Button(frame3, text=" edit ", command = EditContacts)
    button2 = Button(frame3, text="delete", command=delete)
    button1.pack(side = LEFT, fill = X, expand = YES)
    button2.pack(side = RIGHT, fill = X, expand = YES)

    info.mainloop()



