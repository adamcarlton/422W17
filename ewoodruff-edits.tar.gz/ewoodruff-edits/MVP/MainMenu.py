from Tkinter import *
import Contact_UI
import CLI_to_GUI
import addressbook
import fileops
class MainMenu:
    def __init__(self):
        MainMenu = Tk()
        MainMenu.title("AddressBook")

        menubar = Menu(MainMenu)
        filemenu = Menu(menubar, tearoff=0)


        frame1 = Frame(MainMenu, bg='white')
        frame1.pack(side=TOP, fill=X, expand=YES)
        label1 = Label(frame1, text="Saved AddressBooks", bg='white', fg='blue', font='Helvetica -18 bold')
        label2 = Label(frame1, text="          ", bg='white')
        self.name = StringVar()
        entryName = Entry(frame1, textvariable=self.name, bg='white')
        #SearchName = Button(frame1, text="Search", bg='white')
        label3 = Label(frame1, text="", bg='white')
        label4 = Label(frame1, text="  ", bg='white')

        # grid the word "Contacts" and search button
        label1.grid(row=0, column=0)
        label2.grid(row=0, column=2)
        entryName.grid(row=0, column=3)
        #SearchName.grid(row=0, column=4)
        label3.grid(row=0, column=5)
        label4.grid(row=1, column=0)

        #get Address books in local directory
        li = []
        integration = CLI_to_GUI.C_to_G()
        integration.get_Book_List(li) #this function is not working, so I manually appended a test file in order to work on other functions
        aBook = fileops.FileOps.open_address_book("test_address_book")
        #li.append("test_address_book")
        # Setting the listbox of contacts and add a scrollbar
        frame2 = Frame(MainMenu)
        frame2.pack(fill=BOTH, expand=YES)
        scrollbar = Scrollbar(frame2)
        scrollbar.pack(side=RIGHT, fill=Y)

        LB = Listbox(frame2, yscrollcommand=scrollbar.set)

        def ClickName(event):
            """
            Opens the Contact_UI GUI, which is basically the GUI form of the AddressBook class, when a name is clicked
            :param event:
            :return:
            """
            click_name = LB.get(LB.curselection())
            print(click_name)
            mainCG = CLI_to_GUI.C_to_G(click_name)
            addb2 = addressbook.AddressBook
            addb = mainCG.open_GUI_Addb(addb2,click_name)
            mainCG.addb = addb
            Contact_UI.Info(click_name, mainCG)

        # function of click the name of contact in the listbox
        LB.bind('<ButtonRelease-1>', ClickName)
        for item in li:
            LB.insert(END, item)

        # Grid the listbox of contacts and add a scrollbar
        LB.config(yscrollcommand=scrollbar.set)
        LB.pack(fill=BOTH, expand=YES)
        scrollbar.config(command=LB.yview)

        # Setting the button of "Add new contact"
        frame3 = Frame(MainMenu)
        frame3.pack(side=BOTTOM, fill=X)
        entryName2 = Entry(frame3, textvariable=self.name, bg='white')


        def NewBook():
            """
            creates a new addresss book by calling a function in Contact_UI called AddBook. takes the name from the entry box
            :return:
            """
            name = entryName2.get()
            print(entryName2.get())
            new_cg = CLI_to_GUI.C_to_G(name)
            Contact_UI.AddBook(new_cg)


        button = Button(frame3, text="Add New AddressBook", command=NewBook)
        entryName2.grid(row=3, column=3)
        button.grid(row=3, column=4)





        MainMenu.mainloop()
MainMenu()
