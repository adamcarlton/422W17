from Tkinter import *
import AddContact_UI
import ContactInfo_UI
import CLI_to_GUI
import address
import addressbook
import fileops



def Info(TheName, cg):
    addb = addressbook.AddressBook(TheName)
    addb.fileName = TheName
    cg.addb = addb
    cg.open_GUI_Addb(addb,addb.fileName)


    MainPage = Tk()
    MainPage.title("address book:{}".format(TheName))
    #MainPage.geometry('200x100')
    def Undo():
        cg.GUI_undo()
        Info(TheName, cg)
        Info.destroy()
    def Redo():
        cg.GUI_redo()
        Info(TheName, cg)
        Info.destroy()

    menubar = Menu(MainPage)
    filemenu = Menu(menubar, tearoff = 0)
    filemenu.add_command(label = "Undo", command=Undo)
    filemenu.add_command(label = "Redo", command=Redo)
    menubar.add_cascade(label = "File", menu = filemenu)

    MainPage.config(menu = menubar)

    # frame1 show the word "Contacts" and search button
    frame1 = Frame(MainPage, bg = 'white')
    frame1.pack(side = TOP, fill = X, expand = YES)
    label1 = Label(frame1, text = "Contacts", bg = 'white', fg = 'blue', font = 'Helvetica -18 bold')
    label2 = Label(frame1,text = "          ", bg = 'white')
    MainPage.name = StringVar()
    entryName = Entry(frame1, textvariable = MainPage.name, bg = 'white')
    SearchName = Button(frame1, text = "Add New Contact", bg = 'white')
    label3 = Label(frame1,text = "", bg = 'white')
    label4 = Label(frame1,text = "  ", bg = 'white')

    # grid the word "Contacts" and search button
    label1.grid(row = 0, column = 0)
    label2.grid(row = 0, column = 2)
    entryName.grid(row = 0, column = 3)
    SearchName.grid(row = 0, column = 4)
    label3.grid(row = 0, column = 5)
    label4.grid(row = 1, column = 0)

    cg.addb = fileops.FileOps.open_address_book(TheName)
    cg.open_GUI_Addb(cg.addb, cg.addb.fileName)
    li = []

    # Setting the listbox of contacts and add a scrollbar
    frame2 = Frame(MainPage)
    frame2.pack(fill = BOTH, expand = YES)
    scrollbar = Scrollbar(frame2)
    scrollbar.pack(side = RIGHT, fill = Y)

    LB = Listbox(frame2, yscrollcommand=scrollbar.set)

    def ClickName(event):
        click_name = LB.get(LB.curselection())
        print(click_name)
        contact = click_name.split(" ")
        print(contact)
        contact2 = address.Address
        for addresses in cg.addb.to_dict():
            contact1 = addresses["address"]
            contact = contact1["first_name"] + " " + contact1["last_name"]
            if click_name == contact:
                contact2 = contact1
        ContactInfo_UI.Info(click_name,cg,contact2)

    # function of click the name of contact in the listbox
    LB.bind('<ButtonRelease-1>', ClickName)
    for addresses in cg.addb.to_dict():
        info = addresses["address"]
        info2 = info["first_name"] + " " + info["last_name"]
        li.append(info2)
    for item in li:
        LB.insert(END, item)

    # Grid the listbox of contacts and add a scrollbar
    LB.config(yscrollcommand = scrollbar.set)
    LB.pack(fill = BOTH, expand = YES)
    scrollbar.config(command = LB.yview)

    class Hold:
        def __init__self(self):
            pass

        def AddNewContacts(self):
            name = entryName.get()
            AddContact_UI.add_contact(name,cg.addb,cg)

    Hold()

    # Setting the button of "Add new contact"
    frame3 = Frame(MainPage)
    frame3.pack(side = BOTTOM, fill = X)
    holder = Hold()
    button = Button(frame3, text="Add new contact", command=holder.AddNewContacts)
    button.pack(fill = X)



    MainPage.mainloop()

def AddBook(name):
    addb = addressbook.AddressBook(name)
    addb.fileName = name
    new_add_book = CLI_to_GUI.C_to_G(name)
    new_add_book.create_GUI_Addb(addb)
    Info(name, new_add_book)



def SaveContact(cg):
    cg.save_GUI_Addb(cg.addb)


def ConfirmAction(addb, action):
    confirm = Tk()
    confirm.title(action)
    confirm.geometry('550x100')
    frame1 = Frame(confirm)
    frame1.pack()
    label1 = Label(frame1, text="Confirm Action", font='Helvetica -18 bold')
    label1.grid(row=0, column=0)
    frame2 = Frame(confirm)
    frame2.pack(fill=BOTH, expand=YES)
    description =Label(frame2, text = "Are you sure you want to {}?".format(action), font = 'Helvetica -14')
    description.grid(row=0, column=0)
    def yesCommand(action):
        action = "y"
        print(action)
        confirm.destroy()
    def noCommand(action):

        action = "n"
        print(action)
        confirm.destroy()
    yesButton = button1 = Button(frame2, text=" yes ", command = lambda:yesCommand(action))
    noButton  = button2 = Button(frame2, text = " no ", command = lambda:noCommand(action))
    yesButton.grid(row=1, column=0)
    noButton.grid(row=1, column=1)
    confirm.mainloop()